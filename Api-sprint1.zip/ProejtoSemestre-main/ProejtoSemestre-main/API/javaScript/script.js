let score = 0;
let countries = [];
let currentCountry = null;
let correctFlags = [];
let displayedFlags = [];

document.addEventListener("DOMContentLoaded", () => {
  startGame();
});

function startGame() {
  score = 0;
  document.getElementById('score').textContent = `Pontuação: ${score}`;
  correctFlags = [];
  displayedFlags = [];
  document.getElementById('BandeirasCertas').innerHTML = '';
  fetchCountries();
}

async function fetchCountries() {
  try {
    const response = await fetch("https://restcountries.com/v2/all");
    const data = await response.json();
    countries = data.map(country => ({
      name: country.name,
      flag: country.flag
    }));
    nextQuestion();
  } catch (error) {
    console.error("Erro ao carregar os dados dos países:", error);
  }
}

function nextQuestion() {
  if (countries.length === displayedFlags.length) {
    alert("Você já viu todas as bandeiras!");
    return;
  }
  
  let randomIndex;
  do {
    randomIndex = Math.floor(Math.random() * countries.length);
  } while (displayedFlags.includes(countries[randomIndex].name));

  currentCountry = countries[randomIndex];
  document.getElementById("flag").src = currentCountry.flag;
  displayedFlags.push(currentCountry.name);

  const options = generateOptions(currentCountry.name);
  const shuffledOptions = shuffleArray(options);

  const buttons = document.querySelectorAll(".option");
  buttons.forEach((button, index) => {
    button.textContent = shuffledOptions[index];
    button.onclick = () => checkAnswer(button);
  });
}

function generateOptions(correctAnswer) {
  const options = new Set();
  options.add(correctAnswer);

  while (options.size < 4) {
    const randomIndex = Math.floor(Math.random() * countries.length);
    options.add(countries[randomIndex].name);
  }

  return Array.from(options);
}

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

function checkAnswer(button) {
  const selectedAnswer = button.textContent;

  if (selectedAnswer === currentCountry.name) {
    score++;
    correctFlags.push(currentCountry);
    alert("Resposta Correta!");

    const flagImage = document.createElement("img");
    flagImage.src = currentCountry.flag;
    flagImage.classList.add("correct-flag");
    document.getElementById('BandeirasCertas').appendChild(flagImage);
  } else {
    score--;
    alert(`Resposta Errada! A resposta correta era: ${currentCountry.name}`);

    if (correctFlags.length > 0) {
      correctFlags.pop();
      const lastFlag = document.getElementById('BandeirasCertas').lastChild;
      if (lastFlag) {
        lastFlag.remove();
      }
    }
  }

  document.getElementById('score').textContent = `Pontuação: ${score}`;
  nextQuestion();
}
