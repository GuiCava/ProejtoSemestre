let img = document.getElementById("flag")
let searchBtn = document.getElementById("search-btn");
let countryInp = "brazil";
let pais = []
let paisAcertos = []
let acertos = []
let c = 0
let button1 = document.getElementById("button-1")
let button2 = document.getElementById("button-2")
let button3 = document.getElementById("button-3")
let button4 = document.getElementById("button-4")
window.onload = function () {
    function getRandom(min, max) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min) + min);
    }

    let finalURL = `https://restcountries.com/v3.1/all`;
    fetch(finalURL).then((response => response.json())).then((data) => {
        let resposta = data
        while (c<194) {
            
            novoPais = resposta[c]
            pais.push(novoPais)
            c++

            


           
            
        }
        let paisSorteado  = pais[getRandom(1,193)]
        button1.textContent = pais[getRandom(1,193)]['name']['common']
        button2.textContent = pais[getRandom(1,193)]['name']['common']
        button3.textContent = pais[getRandom(1,193)]['name']['common']
        button4.textContent = pais[getRandom(1,193)]['name']['common']
        let = botaoSoteado = getRandom(1,4)
        if (botaoSoteado == 1){
            button1.textContent = paisSorteado['name']['common']
        }
        if (botaoSoteado == 2){
            button2.textContent = paisSorteado['name']['common']
        }
        if (botaoSoteado == 3){
            button3.textContent = paisSorteado['name']['common']
        }
        if (botaoSoteado == 4){
            button4.textContent = paisSorteado['name']['common']
        }

        button1.addEventListener('click',()=>{
            if (button1.textContent == paisSorteado['name']['common']){
            window.alert("voceufs")
            }
            else{
                alert("errou")
            }
        })

        button2.addEventListener('click',()=>{
            if (button2.textContent == paisSorteado['name']['common']){
            window.alert("Acertou")
            }
            else{

                alert("errou")
            }
        })
        button3.addEventListener('click',()=>{
            if (button3.textContent == paisSorteado['name']['common']){
            window.alert("Acertou")
            }
            else{
                alert("errou")
            }
        })
        button4.addEventListener('click',()=>{
            if (button4.textContent == paisSorteado['name']['common']){
            window.alert("Acertou")
            }
            else{
                alert("errou")
            }
        })
        console.log(button1.textContent)
        console.log(button2.textContent)
        console.log(button3.textContent)
        console.log(button4.textContent)

        console.log(paisSorteado['name']['common'])
        img.src = paisSorteado['flags']['png']
        
    }
)
    
    

};